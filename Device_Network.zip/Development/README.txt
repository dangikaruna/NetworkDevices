This program is to find that the host device is connectd to internet or not.



And if the device is connected to the network it scan all the other devices in the sama network and stores the Host status, Address and the type of address, hostname and its types.





commands to rum this file.


make
./task






