#! /bin/sh




sudo apt-get install ifplugd
sudo apt install nmap
