//for Windows
#ifdef linux
#include"header.h"
#include<iostream>
#include<cstdlib>
#include <string.h>
#include<unistd.h>
#endif


//for linux
#ifdef _WIN32
#include"header.h"
#include<iostream>
#include<cstdlib>
#include <string.h>
#include<unistd.h>
#endif

using namespace std;

int find()
{
logger("task is done",__FILE__, __LINE__, __DATE__, __TIME__);

#ifdef linux
while(1)
{
int r=(system("ifplugstatus ens33 >> file.txt"));

printf("%d\n",r);
if(r==512)	
{
       
       cout<<"connected to internet\n";
       int s;
      
      sleep(20);   
       s=system("nmap -sn -oX network.xml `ip addr list ens33 |grep 'inet ' |cut -d' ' -f6` ");
       //printf("%d",s);
       if(s!=0 && s!=256)
       exit(0);
}
       
else if(r==768)
{
cout<<"not connected to internet\n";
}    
else if(r==32512)
{
system("sudo apt install ifplugd");
}
else
exit(0);

}
#endif

return 0;
}




