#include"header.h"
#include<iostream>
#include<stdlib.h>
#include<fstream>

using namespace std;
void logger(const char* msg,const char *src, int line, const char *date, const char *time)
{

ofstream file;
file.open("log.txt", ios::app);
    if(file.fail()){
        cout << "Operation not success!!!" << endl;
        cout << "Status of the failbit: " << file.fail() << endl;
    }

file<<src <<" "<<line <<" "<<msg <<" "<<date <<" "<<time <<" "<<endl;
file.close();
}
